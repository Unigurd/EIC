#include "Lights.hpp"



Lights::Lights()
{
}


Lights::~Lights()
{
}
