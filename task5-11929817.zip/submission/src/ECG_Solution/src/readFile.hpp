#pragma once

#include <string>
#include <filesystem>

std::string readFile(std::filesystem::path p);
