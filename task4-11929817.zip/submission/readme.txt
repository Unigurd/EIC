11929817
Intel(R) HD Graphics 620