#version 430 core

in vec4 FragColor1;
out vec4 FragColor;

void main()
{
    FragColor = FragColor1;
}
